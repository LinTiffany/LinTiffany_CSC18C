/*
 * Author: Tiffany Lin
 * Date: 03/18/2015
 * Class: CSC18C
 * Description: Node class w/ Wrapper that uses Integer
 * 
 */
public class Node{
	public Integer data;//entry in bag
	public Node next;//link to next node
	public Node(){
		data=null;
	}
	public Node(Integer dataEntry){
		data=dataEntry;
	}
	public Node(Integer dataEntry, Node nextN){
		data=dataEntry;
		next = nextN;
	}
	public Integer getData(){
		return data;
	}
	
	public void setData(Integer dataEntry){
		data=dataEntry;
	}
	public void setNext(Node newNode){
		next=newNode;
	}
	public Node getNext(){
		return next;
	}
	
}
