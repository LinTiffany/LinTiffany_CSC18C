/*
 * Author: Tiffany Lin
 * Date: 3/18/2015
 * Class: CSC18C
 * Description: Create a linked list that uses Node class with wrapper Integer
 *  and implements stack
 * 
 */
public class LinkedListWrapper {
	Node head;
	Node next;
	Node index;
	
	public LinkedListWrapper(){
		head=null;
		next=null;

	}
	public void push(Node newNode){
		Node previous=new Node();
		index=head; previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		index.next=newNode;
		newNode.next=null;
	}
	public Node pop(){
		Node previous=new Node();
		index=head;previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		previous.next=null;	//change second-to-last node to null
		return index;
	}
	public void print(){
		index=head; 
		while(index.next!=null){
			System.out.println(index.getData());
			index=index.next;
		}
		System.out.println(index.getData());
	}

	public static void main(String[] args){
		LinkedListWrapper newList=new LinkedListWrapper();
		Node Node1=new Node(100);
		Node Node2=new Node(200);
		Node Node3=new Node(300);
		Node Node4=new Node(400);
		Node Node5=new Node(500);
		newList.head=Node1;
		Node1.next=Node2;
		Node2.next=Node3;
		Node3.next=Node4;
		Node4.next=Node5;
		Node5.next=null;
		//100,200,300,400,500
		newList.pop();//100, 200,300,400

		Node newerNode=new Node(999);
		Node newestNode=new Node(1234);
		newList.push(newerNode);//100,200,300,400,999
		newList.push(newestNode);//100,200,300,400,999,1234
		newList.pop();//100,200, 300,400,999
		newList.print();
	}
}