/*
 * Author: Tiffany Lin
 * Date: 03/18/2015
 * Class: CSC18C
 * Description: Node class that uses primitive data type, int
 * 
 */
public class Node {
	public int data;//entry in bag
	public Node next;//link to next node
	public Node(){
		data=0;
	}
	public Node(int dataEntry){
		data=dataEntry;
	}
	public Node(int dataEntry, Node nextN){
		data=dataEntry;
		next = nextN;
	}
	public int getData(){
		return data;
	}
	
	public void setData(int dataEntry){
		data=dataEntry;
	}
	public void setNext(Node newNode){
		next=newNode;
	}
	public Node getNext(){
		return next;
	}
	
}
