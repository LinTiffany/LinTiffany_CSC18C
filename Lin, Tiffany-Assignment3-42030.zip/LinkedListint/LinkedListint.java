/*
 * Author: Tiffany Lin
 * Date: 3/18/2015
 * Class: CSC18C
 * Description: Create a linked list that uses Node class with primitive data type,int,
 *  and implements stack
 * 
 */
public class LinkedListint {
	Node head;
	Node next;
	Node index;
	
	public LinkedListint(){
		head=null;
		next=null;

	}
	public void push(Node newNode){
		Node previous=new Node();
		index=head; previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		index.next=newNode;
		newNode.next=null;
	}
	public Node pop(){
		Node previous=new Node();
		index=head;previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		previous.next=null;	//change second-to-last node to null
		return index;
	}
	public void print(){
		index=head; 
		while(index.next!=null){
			System.out.println(index.getData());
			index=index.next;
		}
		System.out.println(index.getData());
	}

	public static void main(String[] args){
		LinkedListint newList=new LinkedListint();
		Node Node1=new Node(47);
		Node Node2=new Node(55);
		Node Node3=new Node(130);
		Node Node4=new Node(4);
		Node Node5=new Node(38);
		newList.head=Node1;
		Node1.next=Node2;
		Node2.next=Node3;
		Node3.next=Node4;
		Node4.next=Node5;
		Node5.next=null;
		//47,55,130,4,38
		newList.pop();//47, 55, 130, 4
		newList.pop();//47, 55, 130
		newList.pop();//47, 55
		Node newerNode=new Node(999);
		Node newestNode=new Node(1234);
		newList.push(newerNode);	//47, 55, 999
		newList.push(newestNode);	//47, 55, 999, 1234
		newList.print();
	}
}