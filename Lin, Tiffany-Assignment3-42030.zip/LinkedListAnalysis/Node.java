/*
 * Author: Tiffany Lin
 * Date: 03/18/2015
 * Class: CSC18C
 * Description: Create a Node class w/ Generic that will be used in Linked List
 */
public class Node<T> {
	public T data;//entry in bag
	public Node<T> next;//link to next node
	public Node(){
		data=null;
	}
	public Node(T dataEntry){
		data=dataEntry;
	}
	public Node(T dataEntry, Node<T> nextN){
		data=dataEntry;
		next = nextN;
	}
	public T getData(){
		return data;
	}
	
	public void setData(T dataEntry){
		data=dataEntry;
	}
	public void setNext(Node<T> newNode){
		next=newNode;
	}
	public Node<T> getNext(){
		return next;
	}
	
}
