/*
 * Author: Tiffany Lin
 * Date: 3/18/2015
 * Class: CSC18C
 * Description: Create a Linked List that implements generic Node class and
 *              implements Stack
 */
public class LinkedList<T> {
	Node<T> head;
	Node<T> next;
	Node<T> index;
	
	public LinkedList(){
		head=null;
		next=null;

	}
	public void push(Node<T> newNode){
		Node<T> previous=new Node<>();
		index=head; previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		index.next=newNode;
		newNode.next=null;
	}
	public Node<T> pop(){
		Node<T> previous=new Node<>();
		index=head;previous=head;
		while(index.next!=null){
			previous=index;
			index=index.next;
		}
		previous.next=null;	//change second-to-last node to null
		return index;
	}
	public void print(){
		index=head; 
		while(index.next!=null){
			System.out.println(index.getData());
			index=index.next;
		}
		System.out.println(index.getData());
	}

	public static void main(String[] args){
		LinkedList <Integer> newList=new LinkedList<>();
		Node<Integer> Node1=new Node<>(3);
		Node<Integer> Node2=new Node<>(15);
		Node<Integer> Node3=new Node<>(175);
		Node<Integer> Node4=new Node<>(300);
		Node<Integer> Node5=new Node<>(45);
		newList.head=Node1;
		Node1.next=Node2;
		Node2.next=Node3;
		Node3.next=Node4;
		Node4.next=Node5;
		Node5.next=null;
		
		newList.pop();//3 15 175 300	
		newList.pop();//3 15 175
		Node<Integer> newestNode=new Node<>(999);
		newList.push(newestNode);//3 15 175 999
		newList.print();
	}
}