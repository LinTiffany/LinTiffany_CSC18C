
public class BinaryTree {
	private TreeNode root;
	public BinaryTree(){
		root=null;
	}
	public BinaryTree(int r){
		TreeNode tr=new TreeNode(r);
		root=tr;
	}
	public TreeNode rotateRight(TreeNode n){//single rotation LL
		TreeNode p=new TreeNode();
		p=n.left;
		n.left=p.right;
		p.right=n;
		n=p;
		return n;
	}
	public TreeNode rotateLeft(TreeNode n){//single rotation RR
		TreeNode p=new TreeNode();
		p=n.right;
		n.right=p.left;
		p.left=n;
		n=p;
		return n;
	}
	public TreeNode doubleRotateRL(TreeNode n){
		n.right=rotateRight(n.right);
		return rotateLeft(n);
	}
	public TreeNode doubleRotateLR(TreeNode n){
		n.left=rotateLeft(n.left);
		return rotateRight(n);
	}
	public int height(TreeNode n){
		if(n==null){
			return 0;
		}
		return n.height;
	}
	public int getBalanceFactor(TreeNode n){//get balance factor
		if(n==null){
			return 0;
		}
		return height(n.left)-height(n.right);
	}
	public int max(int leftN, int rightN){
		if(leftN>rightN){
			return leftN;
		}
			return rightN;
	}
	
	public TreeNode insert(TreeNode n, int v){
		if(n==null){
			return (new TreeNode(v));
		}
		if(v<n.getData()){//go left
			if(n.left==null){
				n.left=new TreeNode(v);
				n.height=1;
				return n;
			}else{
				n.left=insert(n.left, v);	
				int balanceFactor=getBalanceFactor(n.left);
				if(balanceFactor>1||balanceFactor<-1){
					if(height(n.left.right)>height(n.left.left)){
						rotateLeft(n.left);
					}else{
						rotateRight(n.left);
					}
				}
				return n;
			}
		}else {
			n.right=insert(n.right, v);	
			int balanceFactor=getBalanceFactor(n.right);
			if(balanceFactor>1||balanceFactor<-1){
				if(height(n.right.right)>height(n.right.left)){
					rotateLeft(n.right);
				}else{
					rotateRight(n.right);
				}
			}
			return n;
		}
		
		//n.height=max(height(n.left),height(n.right));
	//	return n;
	}
	
	public TreeNode delete(TreeNode n, int v){
		if(n.getData()==v){//if data is found in tree
			if(n.right==null&&n.left==null){
				return null;
			}
			else{
				if(max(height(n.left),height(n.right))==height(n.left)){//if left side is heavier
					if(height(n.right)==-1){
						return n.left;
					}else{
						TreeNode index=n.right;
						while(index.left!=null){
							index.left=rotateRight(index.left);
							index.height=max(height(index.left),height(index.right));
						}
						index.left=n.left;
						return index;
					}
				}else if(max(height(n.left),height(n.right))==height(n.right)){//if right side is heavier	
					if(height(n.left)==-1){
						return n.right;
					}else{
						TreeNode index=n.left;
						while(index.right!=null){
							index.right=rotateLeft(index.right);
							index.height=max(height(index.left), height(index.right));
						}
						index.right=n.right;
						return index;
					}
				}else{//both are equally heavy
					TreeNode index=n.right;
					while(index.left!=null){
						index.left=rotateRight(index.left);
						index.height=max(height(index.left),height(index.right));
					}
					index.left=n.left;
					return index;
				}
			}
		}else{
			if(v>n.getData()){
				if(n.right!=null){
					n.right=delete(n.right,v);
					n.right.height=max(height(n.right.left),height(n.right.right));
					int balanceFactor=getBalanceFactor(n.right);
					if(balanceFactor>1||balanceFactor<-1){
						if(height(n.right.right)>height(n.right.left)){
							rotateLeft(n.right);
						}else{
							rotateRight(n.right);
						}
					}
					return n;
				}else{
						return n;
				}
			}else{
					if(n.left!=null){
						n.left=delete(n.left,v);
						n.left.height=max(height(n.left.left),height(n.left.right));
						int balanceFactor=getBalanceFactor(n.left);
						if(balanceFactor>1||balanceFactor<-1){
							if(height(n.left.right)>height(n.left.left)){
								rotateLeft(n.left);
							}else{
								rotateRight(n.left);
							}
						}
						return n;
					}else{
						return n;
				}
			}
		}
	}
	public void preOrder(TreeNode r){
		if(r==null){
			System.out.print("");
		}else{
			System.out.print(r.getData()+" ");
			preOrder(r.left);
			preOrder(r.right);
		}
	}
	public void inOrder(TreeNode r){
		if(r==null){
			System.out.print("");
		}else{
			inOrder(r.left);
			System.out.print(r.getData()+" ");
			inOrder(r.right);
		}
	}
	public void postOrder(TreeNode r){
		if(r==null){
			System.out.print("");
		}else{
			postOrder(r.left);
			postOrder(r.right);
			System.out.print(r.getData()+" ");
		}
	}
	public static void main(String[] args){
		TreeNode root=new TreeNode(8);
		BinaryTree newTree=new BinaryTree();
		int[] list={2,12,9,10,5};
		System.out.println("ORIGINAL INSERT ORDER: ");
		for(int i=0;i<list.length;i++){
			System.out.print(list[i]+ " ");
			newTree.insert(root, list[i]);
		}
		System.out.println();
		System.out.println("PREORDER: ");//Ro, L, R
		newTree.preOrder(root);
		System.out.println();
		System.out.println("POSTORDER: ");//L, Ro, R
		newTree.postOrder(root);
		System.out.println();
		System.out.println("INORDER: ");//L, R, Ro
		newTree.inOrder(root);
		newTree.delete(root, 2);
		newTree.delete(root,0);
		
	}
}
