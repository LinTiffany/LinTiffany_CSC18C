
public class TreeNode {
	private int data;
	TreeNode left, right;
	int height=0;
	public TreeNode(){
		data=0;
		left=null;
		right=null;
	}
	public TreeNode(int d){
		data=d;
		left=null;
		right=null;
		height=1;
	}
	public void setData(int d){
		data=d;
	}
	public int getData(){
		return data;
	}
	public void print(){
		System.out.println(data);
	}
}
