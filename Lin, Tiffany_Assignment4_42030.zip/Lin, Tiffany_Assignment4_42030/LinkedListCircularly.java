/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description:Assignment4- Circularly Linked List
 */
public class LinkedListCircularly {
	Node head;

	int size;

	public LinkedListCircularly(){
		head=null; size=0;
	}


	
	public void insertAtPos(Node newNode, int pos){
		if(pos>size){
			System.out.println("Error");
		}else{
			if(size==0){
				size++;
				head=newNode;
				newNode.next=newNode;
				newNode.previous=newNode;
			}else {  // size > 0
				size++;
				Node thisNode=getNode(pos);
				Node previousNode=thisNode.previous;
				previousNode.next=newNode;
				newNode.next=thisNode;
				thisNode.previous=newNode;
				newNode.previous=previousNode;
			}
			
		}
	}
	public Node getNode(int pos) {
		if(pos<size){
		Node tempNode=head;
		
		int position=0;
		while(position<pos){
			tempNode=tempNode.next;
			position++;
		}
		return tempNode;
		}else
			return null;
	}
	
	public Node delete(int pos){
		if(pos>size){
			System.out.println("Error");
		}else
		{
			if(size==0){
				return null;
			}else if(size==1){
				size--;
				head=null;
				return head;
			}else{
				Node thisNode=getNode(pos);
				Node prevNode=thisNode.previous;
				Node nextNode=thisNode.next;
				prevNode.next=nextNode;
				nextNode.previous=prevNode;
				size--;
				return thisNode;
			}
		}
		return null;
	
	}
	
	public void print(){
		if(size==0){
			System.out.println("Empty");
			
		}else if(size==1){
			System.out.println(head.getData());
		}else{
			Node index=head;
			while(index.next!=head){
				System.out.print(index.getData() + "<->");
				index=index.next;
			}
			System.out.println(index.getData());
		}
		
		
	}
	public static void main(String[] args){
		LinkedListCircularly list=new LinkedListCircularly();//index=null
		Node Node1=new Node(47);
		Node Node2=new Node(55);
		Node Node3=new Node(130);
		Node Node4=new Node(4);
		Node Node5=new Node(38);
		list.insertAtPos(Node1, 0);
		list.insertAtPos(Node2, 1);
		list.insertAtPos(Node3, 2);
		list.insertAtPos(Node4,3);
		list.delete(2);
		list.insertAtPos(Node5, 2);
		list.print();
		
	}
	
}
