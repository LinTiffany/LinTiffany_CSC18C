/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description: Assignment 4:Singularly Linked List
 */
public class LinkedListSingle {
	Node head;
	Node next;
	Node index;
	Node tail;
	
	public LinkedListSingle(){
		head=null;
		next=null;
		tail=null;
	}
	public void pushHead(Node newNode){
		if(head!=null){
		index=head; head=newNode;
		head.next=index;
		}else
			head=newNode;
	}
	public void pushTail(Node newNode){
		if(tail!=null){
		tail.next=newNode;
		tail=newNode;
		}else
			tail=newNode;
	}
	public Node popTail(){
		if(tail!=null){
		index=head;
		while(index.next!=tail){
			index=index.next;
		}
		Node returnNode = tail;
		index.next=null;
		tail=index;
		return returnNode;
		}else
			return null;
	}
	public Node popHead(){
		if(head!=null){
		index=head;
		head=head.next;
		return index;
		}else
			return null;
	}
	public void print(){
		index=head; 
		while(index.next!=null){
			System.out.println(index.getData());
			index=index.next;
		}
		System.out.println(index.getData());
	}

	public static void main(String[] args){
		LinkedListSingle newList=new LinkedListSingle();
		Node Node1=new Node(47);
		Node Node2=new Node(55);
		Node Node3=new Node(130);
		Node Node4=new Node(4);
		Node Node5=new Node(38);
		newList.head=Node1;
		newList.tail=Node5;
		Node1.next=Node2;
		Node2.next=Node3;
		Node3.next=Node4;
		Node4.next=Node5;
		//47,55,130,4,38
		newList.popHead();// 55, 130, 4,38
		newList.popTail();//55, 130, 4
		newList.popHead();//130, 4
		Node newerNode=new Node(999);
		Node newestNode=new Node(1234);
		newList.pushHead(newerNode);//999, 130, 4
		newList.pushTail(newestNode);	//999, 130, 4, 1234
		newList.print();
	}
}
