/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description: Assignment 4:Node class that uses primitive data type, int w/adjustments
 * 
 */
public class Node {
	public int data;//entry in bag
	public Node next;//link to next node
	public Node previous;
	public int priority=0;
	public Node(){
		data=0;
		next=null;
		previous=null;
		priority++;
	}
	public Node(int dataEntry){
		data=dataEntry;
		next=null;
		previous=null;
		priority++;
	}
	public int getPriority(){
		return priority;
	}
	public int getData(){
		priority++;
		return data;
	}
	
	public void setNext(Node newNode){
		next=newNode;
		newNode.priority++;
	}
	
	public void setPrevious(Node newNode){
		previous=newNode;
		newNode.priority++;
	}
	public Node getNext(){
		next.priority++;
		return next;
	}
	public Node getPrevious(){
		previous.priority++;
		return previous;
	}
	
}
