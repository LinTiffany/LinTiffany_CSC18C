/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description: Assignment 4:Linked List Priority Queue
 */
public class LinkedListPriority {
	Node head;
	
	public LinkedListPriority(){
		head=null;
	}
	public LinkedListPriority(Node h){
		head=h;
		
	}
	public Node getPriority(){
		Node index=head;
		Node maxNode=head;
		int max=head.getPriority();//get priority of head
		while(index!=null){
			if(max<index.getPriority()){
				max=index.getPriority();
				maxNode=index;
			}
			index=index.next;
		}
		return maxNode;
	}
	public void addNode(Node newNode){
		newNode.priority++;
		if(head==null){
			head=newNode;
			newNode.priority++;
			head.next=null;
		}else{
			Node index=head;
			while(index.next!=null){
				index=index.next;
			}
			index.next=newNode;
			newNode.previous=index;
			newNode.next=null;
			
		}
	}
	public void delete(Node maxNode){
		maxNode.priority++;
		if(maxNode==head){
			head=head.next;
		}else if(maxNode.next==null){
			Node prevNode=maxNode.previous;
			prevNode.next=null;
		}else{
			Node prevNode=maxNode.previous;
			Node nextNode=maxNode.next;
			prevNode.next=nextNode;
			nextNode.previous=prevNode;
		}
	}
	public void print(){
		Node index=head;
		while(index!=null){
			System.out.print("//Priority: "+index.getPriority() + " Data: "+index.getData());
			index=index.next;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListPriority randomList=new LinkedListPriority();
		LinkedListPriority priorityQueue=new LinkedListPriority();
		Node node1=new Node(25);
		Node node2=new Node(24);
		Node node3=new Node(15);
		Node node4=new Node(77);
		randomList.addNode(node1);
		randomList.addNode(node2);
		randomList.addNode(node3);
		randomList.addNode(node4);
		Node index=randomList.head;
		while(index!=null){
			Node maxNode=randomList.getPriority();
			System.out.println("Delete" +maxNode.getData()+" // "+ maxNode.getPriority());

			randomList.delete(maxNode);
			priorityQueue.addNode(maxNode);
			index = randomList.head;
			
		}
		System.out.print("Sorted by Priority: "); priorityQueue.print();
		
		
		
	}

}
