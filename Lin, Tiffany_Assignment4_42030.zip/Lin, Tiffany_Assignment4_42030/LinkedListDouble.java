/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description:Assignment4- Doubly Linked List
 */
public class LinkedListDouble{
	Node head;

	int size;

	public LinkedListDouble(){
		head=null; size=0;
	}

	
	public void pushHead(Node newNode){
		size++;
		if(head!=null){
		newNode.next=head;
		head.previous=newNode;
		head=newNode;
		}else
			head=newNode;
	}
	public void pushTail(Node newNode){
		size++;
		Node index=head;
		while(index.next!=null){
			index.previous=index;
			index=index.next;
		}
		index.next=newNode;
		newNode.previous=index;
		index=newNode;
	}
	public Node popTail(){
		if(size==1){
			size--;
			head=null;
			return head;
		}else if (size>=1){
		size--;
		Node index=head;
		while(index.next!=null){
			index.previous=index;
			index=index.next;
		}
		Node previous=index.previous;
		Node trashNode=index;
		previous.next=null;
		index=previous;
		return trashNode;
		}
		
			return null;
	}
	public Node popHead(){
		if(head!=null){
			Node tempNode=head;
			head=head.next;
			tempNode.next=null;
			return tempNode;
		}else
			return null;
	}
	
	
	public void print(){
		if(size==0){
			System.out.println("Empty");
			
		}else if(size==1){
			System.out.println(head.getData());
		}else{
			Node index=head;
			while(index.next!=null){
				System.out.print(index.getData() + "<->");
				index=index.next;
			}
			System.out.println(index.getData());
		}
		
		
	}
	public static void main(String[] args){
		LinkedListDouble list=new LinkedListDouble();//index=null
		Node Node1=new Node(47);
		Node Node2=new Node(55);
		Node Node3=new Node(130);
		Node Node4=new Node(4);
		Node Node5=new Node(38);
		list.pushHead(Node1);
		list.pushTail(Node2);
		list.pushHead(Node3);
		list.pushHead(Node4);
		list.pushHead(Node5);//38,4, 130,47,55
		list.popTail(); //38,4, 130, 47
		list.popHead();//4, 130, 47
		list.print();
		
	}
	
}
