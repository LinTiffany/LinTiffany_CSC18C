/*
 * Author: Tiffany Lin
 * Date: 04/01/2015
 * Class: CSC18C
 * Description: Assignment 4: Sorted Linked List
 */
public class LinkedListSorted {
	private Node head;
	
	
	public LinkedListSorted(){
		head=null;
		
	}
	public LinkedListSorted(Node h){
		head=h;
	}
	public Node getMax(){
		Node index=head;
		Node maxNode=head;
		int max=head.getData();
		while(index!=null){
			if(max<index.getData()){
				max=index.getData();
				maxNode=index;
			}
			index=index.next;
		}
		return maxNode;
	}
	public void addNode(Node newNode){
		if(head==null){
			head=newNode;
			head.next=null;
		}else{
			Node index=head;
			while(index.next!=null){
				index=index.next;
			}
			index.next=newNode;
			newNode.previous=index;
			newNode.next=null;
			
		}
	}
	public void delete(Node maxNode){
	
		if(maxNode==head){
			head=head.next;
		}else if(maxNode.next==null){
			Node prevNode=maxNode.previous;
			prevNode.next=null;
		}else{
			Node prevNode=maxNode.previous;
			Node nextNode=maxNode.next;
			prevNode.next=nextNode;
			nextNode.previous=prevNode;
		}
	}	
	public void print(){
		Node index=head;
		while(index!=null){
			System.out.print(index.getData() + "<->");
			index=index.next;
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSorted newList=new LinkedListSorted();
		LinkedListSorted sortedList=new LinkedListSorted();
		Node node1=new Node(1);
		Node node2=new Node(24);
		Node node3=new Node(9);
		Node node4=new Node(55);
		newList.addNode(node1);
		newList.addNode(node2);
		newList.addNode(node3);
		newList.addNode(node4);
		System.out.print("Original List: ");newList.print();
		Node index=newList.head;
		while(index!=null){
			Node maxNode=newList.getMax();
			System.out.println("Delete " + maxNode.getData());

			newList.delete(maxNode);
			sortedList.addNode(maxNode);
			index = newList.head;
			
		}
		System.out.print("Sorted List: "); sortedList.print();
	}

}
